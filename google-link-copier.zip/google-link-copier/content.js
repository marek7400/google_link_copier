let hoveredLink = null;

// Funkcja czyszcząca i dekodująca URL Google
function getCleanUrl(url) {
    if (!url) return '';
    try {
        const parsedUrl = new URL(url);

        if (parsedUrl.pathname === '/url' && parsedUrl.searchParams.has('q')) {
            return decodeURIComponent(parsedUrl.searchParams.get('q'));
        } else if (parsedUrl.searchParams.has('url')) {
            return decodeURIComponent(parsedUrl.searchParams.get('url'));
        } else if (parsedUrl.searchParams.has('adurl')) {
            return decodeURIComponent(parsedUrl.searchParams.get('adurl'));
        }

        return decodeURIComponent(url);
    } catch (e) {
        return url;
    }
}

// Toast info
function showToast(message) {
    let toast = document.getElementById('google-link-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'google-link-toast';
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.right = '20px';
        toast.style.padding = '12px 16px';
        toast.style.background = '#333';
        toast.style.color = '#fff';
        toast.style.borderRadius = '4px';
        toast.style.zIndex = '9999';
        toast.style.boxShadow = '0 2px 8px rgba(0,0,0,0.2)';
        toast.style.fontFamily = 'Arial, sans-serif';
        toast.style.transition = 'opacity 0.3s';
        document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    clearTimeout(toast.hideTimeout);
    toast.hideTimeout = setTimeout(() => {
        toast.style.opacity = '0';
    }, 2000);
}

// Obsługa najechania na link
document.addEventListener('mouseover', function(e) {
    const link = e.target.closest('a');
    if (link && link.href) {
        hoveredLink = link;
        link.style.outline = '2px solid rgba(66, 133, 244, 0.3)';
    }
}, true);

// Obsługa opuszczenia linku
document.addEventListener('mouseout', function(e) {
    const link = e.target.closest('a');
    if (link) {
        link.style.outline = '';
        if (hoveredLink === link) {
            hoveredLink = null;
        }
    }
}, true);

// Obsługa Ctrl+C
document.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'c' && hoveredLink) {
        if (window.getSelection().toString() !== '') return;

        const cleanUrl = getCleanUrl(hoveredLink.href);
        navigator.clipboard.writeText(cleanUrl).then(() => {
            hoveredLink.style.backgroundColor = 'rgba(76, 175, 80, 0.2)';
            setTimeout(() => {
                hoveredLink.style.backgroundColor = '';
            }, 300);
            showToast('Skopiowano: ' + cleanUrl);
        });

        e.preventDefault();
        e.stopPropagation();
    }
}, true);

console.log('✅ Google Link Copier (rozszerzenie) załadowane');
